"""Short complete BF16 request, independent timings and diagnostic profiles."""
import argparse
import json
import statistics
from pathlib import Path

import torch
from benchmark import drain,engine_for,workload
from vllm_rlt.layers import RotaryEmbedding
from vllm_rlt.models import DoryForCausalLM,load_tokenizer


def main(args):
    torch.set_num_threads(1)
    torch.manual_seed(42)
    checkpoint=args.root/'weights/dory'
    tokenizer=load_tokenizer(checkpoint)
    model=DoryForCausalLM.from_pretrained(checkpoint,device='cuda',dtype=torch.bfloat16,loops=2)
    engine=engine_for(model,'sync_eager')
    prompts=workload(tokenizer,128,1)
    generated=4
    drain(engine,prompts,2,generated,'warmup')
    runs=[drain(engine,prompts,2,generated,'unprofiled-'+str(i)) for i in range(3)]
    print('UNPROFILED_SHORT_REQUEST',args.arm,statistics.median(r['throughput'] for r in runs),flush=True)
    original=RotaryEmbedding.forward
    def annotated(module,hidden,positions):
        with torch.profiler.record_function('dory_rope_values'):
            return original(module,hidden,positions)
    RotaryEmbedding.forward=annotated
    params=__import__('vllm_rlt').SamplingParams(max_tokens=generated,min_loops=2,max_loops=2,ignore_eos=True)
    records={}
    try:
        for kind in ('ops-only','full'):
            full=kind=='full'
            drain(engine,prompts,2,generated,'profile-warmup')
            torch.cuda.synchronize()
            outputs={}
            steps=0
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA],record_shapes=full,profile_memory=full,with_stack=full) as prof:
                with torch.profiler.record_function('complete_request'):
                    engine.add_request('0',prompts[0],params)
                    phase=torch.profiler.record_function('prefill_to_first_token')
                    phase.__enter__()
                    first=True
                    try:
                        while engine.has_unfinished_requests():
                            emitted=False
                            for output in engine.step():
                                emitted=emitted or bool(output.token_ids)
                                if output.finished: outputs[output.request_id]=dict(ids=output.token_ids,depths=output.exit_depths,finish_reason=output.finish_reason)
                            steps+=1
                            if first and emitted:
                                phase.__exit__(None,None,None)
                                phase=torch.profiler.record_function('decode')
                                phase.__enter__()
                                first=False
                        engine.model_runner.synchronize()
                        torch.cuda.synchronize()
                    finally:
                        phase.__exit__(None,None,None)
            assert outputs==runs[0]['outputs']
            assert not first and all(len(x['ids'])==generated for x in outputs.values())
            trace=args.root/f'request-{args.arm}-{kind}.json'
            prof.export_chrome_trace(str(trace))
            stats={x.key:dict(count=x.count,cpu_us=x.self_cpu_time_total,device_us=x.self_device_time_total) for x in prof.key_averages()}
            records[kind]=dict(stats=stats,trace_bytes=trace.stat().st_size,events=len(prof.events()),steps=steps,outputs=outputs)
            print('COMPLETE_REQUEST_PROFILE',args.arm,kind,trace.stat().st_size,stats['dory_rope_values']['count'],flush=True)
            del prof
        (args.root/f'request-{args.arm}-summary.json').write_text(json.dumps(dict(arm=args.arm,input_tokens=128,output_tokens=generated,mode='sync_eager',loops=2,unprofiled_runs=runs,profiles=records),indent=2))
    finally:
        engine.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--arm',required=True)
    with torch.inference_mode(): main(p.parse_args())
