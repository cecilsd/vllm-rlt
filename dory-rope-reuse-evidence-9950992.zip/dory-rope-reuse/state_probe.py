"""Save real-weight hidden states, logits, and valid KV for exact A/B comparison."""
import argparse
import gc
from pathlib import Path

import torch

from vllm_rlt.core.kv_cache_manager import KVCacheManager
from vllm_rlt.models import DoryForCausalLM, load_tokenizer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--arm', required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    checkpoint = args.root/'weights/dory'
    tokenizer = load_tokenizer(checkpoint)
    tokens = tokenizer.encode('The capital of France is Paris, and its river is', add_special_tokens=False)[:10]
    for loops in (1, 2, 4):
        model = DoryForCausalLM.from_pretrained(checkpoint, device='cuda',
                                               dtype=torch.bfloat16, loops=loops)
        cfg = model.config
        cache = KVCacheManager(num_layers=cfg.num_kv_layers, num_kv_heads=cfg.num_key_value_heads,
            head_dim=cfg.head_dim, num_blocks=128, block_size=16, max_loops=loops, device='cuda',
            dtype=torch.bfloat16, backend='triton', layout=cfg.kv_cache_layout,
            recurrent_layers=model.recurrent_kv_layers)
        assert cache.allocate('request', len(tokens))
        states, logits = [], []
        for position, token in enumerate(tokens):
            boundary = cache._prepare_batch(['request'], [0], [position])
            hidden = model.prelude_prepared(torch.tensor([token], device='cuda'), boundary, cache)
            states.append(hidden.cpu())
            for depth in range(loops):
                batch = cache._prepare_batch(['request'], [depth], [position])
                hidden, _ = model.recurrent_prepared(hidden, batch, cache)
                states.append(hidden.cpu())
            logits.append(model.coda_prepared(hidden, boundary, cache).cpu())
        kv = {}
        for layer in range(cfg.num_kv_layers):
            for depth in range(loops) if layer in model.recurrent_kv_layers else (0,):
                kv[f'{layer}-{depth}'] = tuple(t.cpu() for t in cache.read(layer, 'request', depth))
        torch.save(dict(states=states, logits=logits, kv=kv, tokens=tokens),
                   args.root/f'states-{args.arm}-{loops}.pt')
        print('STATE_SAVED', args.arm, loops, len(states), len(kv), flush=True)
        del model, cache, kv, states, logits, hidden
        gc.collect()
        torch.cuda.empty_cache()


if __name__ == '__main__':
    with torch.inference_mode():
        main()
