"""Generate matched timing plots from sanitized diagnostic traces."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Patch


def span(e):return e['ts'],e['ts']+e.get('dur',0)
def overlap(e,start,end):return e.get('ph')=='X' and e['ts']<end and e['ts']+e.get('dur',0)>start

def union(intervals):
    merged=[]
    for start,end in sorted(intervals):
        if merged and start<=merged[-1][1]:merged[-1]=(merged[-1][0],max(end,merged[-1][1]))
        else:merged.append((start,end))
    return sum(b-a for a,b in merged)


def load(path):
    raw=json.loads(path.read_text());ev=raw['traceEvents']
    request=next(x for x in ev if x.get('cat')=='user_annotation' and x.get('name')=='complete_request')
    start,end=span(request)
    phases=[x for x in ev if x.get('cat')=='user_annotation' and x.get('name') in ('prefill_to_first_token','decode')]
    cpu=[x for x in ev if x.get('cat')=='cpu_op' and overlap(x,start,end)]
    runtime=[x for x in ev if x.get('cat')=='cuda_runtime' and overlap(x,start,end)]
    kernels=[x for x in ev if x.get('cat')=='kernel' and overlap(x,start,end)]
    ropes=[x for x in ev if x.get('cat')=='user_annotation' and x.get('name')=='dory_rope_values' and overlap(x,start,end)]
    result={}
    for name,selected in [('prefill',[x for x in phases if x['name']=='prefill_to_first_token']),('decode',[x for x in phases if x['name']=='decode'])]:
        ranges=[span(x) for x in selected]
        choose=lambda x:any(overlap(x,a,b) for a,b in ranges)
        ks=[x for x in kernels if choose(x)]
        rs=[x for x in runtime if choose(x)]
        busy=union([span(x) for x in ks])
        wall=sum(b-a for a,b in ranges)
        result[name]=dict(profiled_host_window_ms=wall/1000,kernel_count=len(ks),kernel_sum_ms=sum(x['dur'] for x in ks)/1000,kernel_interval_union_ms=busy/1000,non_kernel_window_ms=(wall-busy)/1000,launches=sum('Launch' in x['name'] for x in rs),runtime_sync_calls=sum('Synchronize' in x['name'] for x in rs),runtime_sync_sum_ms=sum(x['dur'] for x in rs if 'Synchronize' in x['name'])/1000,memcpy_count=sum(x.get('cat')=='gpu_memcpy' and choose(x) for x in ev),rope_evaluations=sum(choose(x) for x in ropes))
    streams=sorted({x['args'].get('stream',x['tid']) for x in kernels})
    return dict(events=ev,start=start,end=end,phases=phases,cpu=cpu,runtime=runtime,kernels=kernels,ropes=ropes,streams=streams,stats=result)


def plot_pair(arms,out,zoom=False):
    allstreams=sorted(set(s for a in arms.values() for s in a['streams']))
    fig,axes=plt.subplots(2,1,figsize=(15,6.2 if not zoom else 5.8),sharex=True)
    if zoom:
        starts={k:min(x['ts'] for x in v['phases'] if x['name']=='decode') for k,v in arms.items()}
        # Same scale: fixed first 6ms of decode in both arms.
        width=6
    else:
        starts={k:v['start'] for k,v in arms.items()}
        width=max((v['end']-v['start'])/1000 for v in arms.values())
    colors={'cpu':'#4b7b9e','runtime':'#e19b34','kernel':'#2c9976','rope':'#d35065'}
    for ax,(name,a) in zip(axes,arms.items()):
        zero=starts[name];last=zero+width*1000
        rows=[('CPU operators',a['cpu'],colors['cpu']),('CUDA runtime',a['runtime'],colors['runtime'])]
        rows += [('GPU stream '+str(i),[e for e in a['kernels'] if e['args'].get('stream',e['tid'])==i],colors['kernel']) for i in allstreams]
        rows += [('RoPE values',a['ropes'],colors['rope'])]
        for y,(label,events,color) in enumerate(rows):
            seg=[((max(e['ts'],zero)-zero)/1000,(min(e['ts']+e.get('dur',0),last)-max(e['ts'],zero))/1000) for e in events if overlap(e,zero,last)]
            if seg:ax.broken_barh(seg,(y-.25,.5),facecolors=color,linewidth=0,rasterized=True)
        for e in a['phases']:
            x=(e['ts']-zero)/1000
            if 0<=x<=width:ax.axvline(x,color='#6b7280',alpha=.45,linewidth=.8)
        if not zoom:
            first=next(x for x in a['phases'] if x['name']=='prefill_to_first_token')
            boundary=(first['ts']+first['dur']-zero)/1000
            ax.axvspan(0,boundary,color='#e8f0fc',alpha=.3,zorder=-5)
            ax.text(boundary/2,len(rows)-.35,'Prefill → first token',ha='center',fontsize=9,color='#3d4c68')
            ax.text((boundary+width)/2,len(rows)-.35,'Decode',ha='center',fontsize=9,color='#3d4c68')
        ax.set_yticks(range(len(rows)),[r[0] for r in rows],fontsize=8)
        ax.set_ylim(-.6,len(rows)+.25)
        ax.set_xlim(0,width)
        ax.grid(axis='x',alpha=.15)
        ax.spines[['top','right']].set_visible(False)
        ax.set_title(('A — main' if name=='baseline' else 'B — RoPE reuse')+f"  |  {(a['end']-a['start'])/1000:.1f} ms profiled / {len(a['kernels']):,} kernels / {len(a['ropes'])} RoPE evaluations",loc='left',fontsize=11,fontweight='bold')
        target=next((e for e in a['ropes'] if overlap(e,zero,last)),None)
        if zoom and target:
            ax.annotate('Repeated per layer' if name=='baseline' else 'Shared per attention type',xy=((target['ts']-zero)/1000,len(rows)-1),xytext=(width*.48,len(rows)-.3),fontsize=9,color=colors['rope'],arrowprops=dict(arrowstyle='->',color=colors['rope']),bbox=dict(boxstyle='round,pad=.25',fc='white',ec=colors['rope'],alpha=.9))
    axes[-1].set_xlabel('Milliseconds from '+('first decode step' if zoom else 'request start')+' — identical scale in both panels')
    fig.suptitle('Dory BF16 · RTX 5090 · sync eager · 128 input / 4 output · 2 loops'+('\nFirst decode step, matching 6 ms window' if zoom else '\nComplete warmed request; profiler enabled — diagnostic timing only'),fontsize=13,fontweight='bold')
    fig.tight_layout(rect=[0,0,1,.90])
    fig.savefig(out,dpi=160)
    plt.close(fig)


def main(root):
    arms={a:load(root/f'request-{a}-ops-only.json') for a in ('baseline','candidate')}
    plot_pair(arms,root/'request-timeline.png')
    plot_pair(arms,root/'request-decode-zoom.png',zoom=True)
    summary={a:dict(stats=v['stats'],total_kernel_count=len(v['kernels']),rope_evaluations=len(v['ropes']),streams=len(v['streams'])) for a,v in arms.items()}
    (root/'timeline-analysis.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);main(p.parse_args().root)
