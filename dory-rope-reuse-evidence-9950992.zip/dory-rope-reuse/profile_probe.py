"""One warmed recurrent traversal: independent ops-only and full profiles."""
import argparse
import json
from pathlib import Path

import torch

from vllm_rlt.core.kv_cache_manager import KVCacheManager
from vllm_rlt.layers import RotaryEmbedding
from vllm_rlt.models import DoryForCausalLM, load_tokenizer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--arm', required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    checkpoint = args.root/'weights/dory'
    model = DoryForCausalLM.from_pretrained(checkpoint, device='cuda', dtype=torch.bfloat16)
    cfg = model.config
    cache = KVCacheManager(num_layers=cfg.num_kv_layers, num_kv_heads=cfg.num_key_value_heads,
        head_dim=cfg.head_dim, num_blocks=128, block_size=16, max_loops=2, device='cuda',
        dtype=torch.bfloat16, backend='triton', layout=cfg.kv_cache_layout,
        recurrent_layers=model.recurrent_kv_layers)
    ids = load_tokenizer(checkpoint).encode('The capital of France is Paris.', add_special_tokens=False)
    assert cache.allocate('request', len(ids))
    requests, positions = ['request']*len(ids), list(range(len(ids)))
    boundary = cache._prepare_batch(requests, [0]*len(ids), positions)
    hidden = model.prelude_prepared(torch.tensor(ids, device='cuda'), boundary, cache)
    batch = cache._prepare_batch(requests, [0]*len(ids), positions)
    model.recurrent_prepared(hidden, batch, cache)
    hidden = hidden[-1:]
    batch = cache._prepare_batch(['request'], [0], [len(ids)-1])
    for _ in range(3):
        model.recurrent_prepared(hidden, batch, cache)
    torch.cuda.synchronize()
    original = RotaryEmbedding.forward

    def annotated(module, hidden, positions):
        with torch.profiler.record_function('dory_rope_values'):
            return original(module, hidden, positions)

    RotaryEmbedding.forward = annotated
    summary = {}
    for kind in ('ops-only', 'full'):
        full = kind == 'full'
        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                                torch.profiler.ProfilerActivity.CUDA],
                record_shapes=full, profile_memory=full, with_stack=full) as profile:
            with torch.profiler.record_function('dory_recurrent_traversal'):
                model.recurrent_prepared(hidden, batch, cache)
            torch.cuda.synchronize()
        trace = args.root/f'profile-{args.arm}-{kind}.json'
        profile.export_chrome_trace(str(trace))
        stats = {}
        for item in profile.key_averages():
            stats[item.key] = dict(count=item.count, cpu_us=item.self_cpu_time_total,
                                  device_us=item.self_device_time_total)
        summary[kind] = dict(trace_bytes=trace.stat().st_size, stats=stats,
                             events=len(profile.events()), full=full)
        if full:
            profile.export_stacks(str(args.root/f'profile-{args.arm}-stacks.txt'),
                                  metric='self_cpu_time_total')
        print('PROFILE_EXPORTED', args.arm, kind, trace.stat().st_size,
              'rope_calls', stats.get('dory_rope_values'), flush=True)
    (args.root/f'profile-{args.arm}-summary.json').write_text(json.dumps(summary, indent=2))


if __name__ == '__main__':
    with torch.inference_mode():
        main()
