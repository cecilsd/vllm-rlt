"""Summarize matched real-checkpoint arms; never infer missing results."""
import argparse
import json
import statistics
from pathlib import Path

import numpy as np
import torch


def compare(left, right, path='root'):
    if isinstance(left, torch.Tensor):
        assert torch.equal(left, right), path
        return left.numel()
    if isinstance(left, dict):
        assert left.keys() == right.keys(), path
        return sum(compare(left[k], right[k], path+'/'+str(k)) for k in left)
    if isinstance(left, (tuple, list)):
        assert len(left) == len(right), path
        return sum(compare(a, b, path+'/'+str(i)) for i, (a, b) in enumerate(zip(left, right)))
    assert left == right, (path, left, right)
    return 0


def key(record):
    return record['loops'], record['mode'], record['input_tokens'], record['batch']


def summarize(root):
    result = dict(correctness=[], states=[], performance=[], profiles={})
    paths = {arm: root/f'correctness-{arm}-0.json' for arm in ('baseline', 'candidate')}
    if all(p.exists() for p in paths.values()):
        arms = {arm: {key(r): r for r in json.loads(path.read_text())['records']}
                for arm, path in paths.items()}
        assert arms['baseline'].keys() == arms['candidate'].keys()
        for cfg, record in arms['baseline'].items():
            other = arms['candidate'][cfg]
            assert record['prompt_sha256'] == other['prompt_sha256']
            for baseline_run, candidate_run in zip(record['runs'], other['runs']):
                compare(baseline_run['outputs'], candidate_run['outputs'])
            result['correctness'].append(dict(config=cfg, matched_requests=record['batch']))
    for loops in (1, 2, 4):
        left, right = [root/f'states-{arm}-{loops}.pt' for arm in ('baseline', 'candidate')]
        if left.exists() and right.exists():
            count = compare(torch.load(left, map_location='cpu', weights_only=True),
                            torch.load(right, map_location='cpu', weights_only=True))
            result['states'].append(dict(loops=loops, exact_tensor_elements=count))
    perf = {}
    for path in sorted(root.glob('performance-*.json')):
        if 'quick' in path.name:
            continue
        data = json.loads(path.read_text())
        for r in data['records']:
            if r['input_tokens'] == 33:
                continue
            perf.setdefault(key(r), {}).setdefault(data['arm'], []).append(r)
    for cfg, arms in perf.items():
        if not all(len(arms.get(a, [])) == 3 for a in ('baseline', 'candidate')):
            continue
        for left, right in zip(arms['baseline'], arms['candidate']):
            assert left['prompt_sha256'] == right['prompt_sha256']
            compare(left['runs'][0]['outputs'], right['runs'][0]['outputs'])
        entry = dict(config=cfg)
        for arm, records in arms.items():
            runs = [run for r in records for run in r['runs']]
            entry[arm] = dict(
                tps_median=statistics.median(r['throughput'] for r in runs),
                tps_range=[min(r['throughput'] for r in runs), max(r['throughput'] for r in runs)],
                ttft_ms=statistics.median(statistics.median(r['ttft_s'])*1000 for r in runs),
                gap_median_ms=statistics.median(statistics.median(r['gaps_s'])*1000 for r in runs),
                gap_p95_ms=statistics.median(float(np.percentile(r['gaps_s'], 95))*1000 for r in runs),
                peak_allocated=max(r['peak_allocated'] for r in records),
                init_s=statistics.median(r['init_s'] for r in records))
        result['performance'].append(entry)
    for path in root.glob('profile-*-summary.json'):
        result['profiles'][path.stem] = json.loads(path.read_text())
    (root/'summary.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({k: v for k, v in result.items() if k != 'profiles'}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    summarize(parser.parse_args().root)
