"""Local experiment only: matched checkpoint correctness and unprofiled timings."""
import argparse
import gc
import hashlib
import json
import statistics
import time
from pathlib import Path

import torch

from vllm_rlt import CacheConfig, ExecutionConfig, SamplingParams, SchedulerConfig
from vllm_rlt.engine.stage_engine import StageEngine
from vllm_rlt.models import DoryForCausalLM, load_tokenizer


MODES = {
    'sync_eager': {},
    'sync_graph': dict(cuda_graphs=True),
    'async_eager': dict(async_scheduling=True),
    'async_graph': dict(async_scheduling=True, cuda_graphs=True),
    'sync_packed': dict(packed_prefill=True),
}
TEXT = ('Inference engines process language model requests with variable input lengths. '
        'Rotary position embeddings depend on absolute token positions and their frequency '
        'parameters. Sharing those values across layers should preserve the model outputs. ')


def workload(tokenizer, length, batch):
    ids = tokenizer.encode(TEXT * (length // 20 + 2), add_special_tokens=False)
    assert len(ids) >= length + batch
    return [ids[index:index+length] for index in range(batch)]


def engine_for(model, mode):
    return StageEngine(model, attention_backend='triton',
        cache_config=CacheConfig(num_blocks=768, block_size=16),
        scheduler_config=SchedulerConfig(max_num_seqs=4, max_num_batched_tokens=128,
                                        prefill_chunk_size=128),
        execution_config=ExecutionConfig(**({'packed_prefill': False} | MODES[mode])))


def drain(engine, prompts, loops, count, label, inspect=False):
    params = SamplingParams(max_tokens=count, min_loops=loops, max_loops=loops, ignore_eos=True)
    torch.cuda.synchronize()
    start = time.perf_counter()
    for index, prompt in enumerate(prompts):
        engine.add_request(str(index), prompt, params)
    observed, first, gaps, finished = {}, {}, [], {}
    checks = []
    steps = 0
    while engine.has_unfinished_requests():
        for output in engine.step():
            now = time.perf_counter()
            rid = output.request_id
            old_count, old_time = observed.get(rid, (0, None))
            new_count = len(output.token_ids)
            if new_count > old_count:
                # Ordinary generation emits one token; do not invent timestamps for batches.
                assert new_count == old_count + 1, (rid, new_count, old_count)
                if old_time is None:
                    first[rid] = now - start
                else:
                    gaps.append(now - old_time)
                observed[rid] = new_count, now
            if output.finished:
                finished[rid] = dict(ids=output.token_ids, depths=output.exit_depths,
                                     finish_reason=output.finish_reason)
        steps += 1
        if inspect and steps <= 6:
            checks.append(steps)
        assert steps < 100000, 'engine stalled'
    engine.model_runner.synchronize()
    elapsed = time.perf_counter() - start
    assert len(finished) == len(prompts)
    assert all(len(item['ids']) == count for item in finished.values())
    assert engine.cache_manager.num_used_blocks == 0
    return dict(label=label, elapsed_s=elapsed, ttft_s=list(first.values()), gaps_s=gaps,
                output_tokens=count*len(prompts), throughput=count*len(prompts)/elapsed,
                outputs=finished, steps=steps)


def graphs(engine):
    runner = engine.model_runner
    return {name: {key: getattr(value, key) for key in ('captures', 'replays', 'fallbacks')}
            for name in ('prelude_graphs', 'graphs', 'coda_graphs')
            if (value := getattr(runner, name, None)) is not None}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--arm', required=True)
    parser.add_argument('--phase', choices=['correctness', 'performance'], required=True)
    parser.add_argument('--round', type=int, default=0)
    parser.add_argument('--only-mode', choices=tuple(MODES))
    parser.add_argument('--quick', action='store_true')
    parser.add_argument('--repeats', type=int, default=1)
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.manual_seed(42)
    checkpoint = args.root/'weights/dory'
    tokenizer = load_tokenizer(checkpoint)
    output = args.root/(f'{args.phase}-{args.arm}-{args.round}'+(f'-{args.only_mode}' if args.only_mode else '')+'.json')
    data = dict(arm=args.arm, phase=args.phase, torch=torch.__version__,
                device=torch.cuda.get_device_name(), checkpoint_revision='ee517dd388a9b348890ae1e00dacc5eb4d0c750d',
                records=[], settings=dict(kv_blocks=768, block_size=16, chunk=128, packed=False))
    def save():
        output.write_text(json.dumps(data, indent=2))
    loops_values = (1, 2, 4) if args.phase == 'correctness' else (2,)
    for loops in loops_values:
        load_start = time.perf_counter()
        model = DoryForCausalLM.from_pretrained(checkpoint, device='cuda', dtype=torch.bfloat16,
                                               loops=loops)
        torch.cuda.synchronize()
        load_s = time.perf_counter() - load_start
        modes = MODES if args.phase == 'performance' else [k for k in MODES if k != 'sync_packed']
        for mode in ([args.only_mode] if args.only_mode else modes):
            cases = [(33, 3, 12)] if args.phase == 'correctness' else [(128, 1, 32), (2048, 1, 32), (128, 4, 32)]
            if args.quick: cases = [(33, 1, 4)]
            for length, batch, generated in cases:
                torch.cuda.reset_peak_memory_stats()
                init_start = time.perf_counter()
                engine = engine_for(model, mode)
                torch.cuda.synchronize()
                init_s = time.perf_counter()-init_start
                prompts = workload(tokenizer, length, batch)
                warm = drain(engine, prompts, loops, generated, 'warmup')
                repeats = 1 if args.phase == 'correctness' else args.repeats
                runs = [drain(engine, prompts, loops, generated, f'measured-{repeat}')
                        for repeat in range(repeats)]
                if 'graph' in mode:
                    assert all(info['replays'] > 0 for info in graphs(engine).values())
                record = dict(loops=loops, mode=mode, input_tokens=length, batch=batch,
                              generated=generated, prompt_sha256=[hashlib.sha256(bytes(str(p),'utf-8')).hexdigest() for p in prompts],
                              load_s=load_s, init_s=init_s, warmup=warm, runs=runs,
                              graphs=graphs(engine), peak_allocated=torch.cuda.max_memory_allocated(),
                              peak_reserved=torch.cuda.max_memory_reserved())
                data['records'].append(record)
                save()
                print('DONE', args.phase, args.arm, loops, mode, length, batch,
                      'tps', round(statistics.median(r['throughput'] for r in runs), 3), flush=True)
                engine.close()
                del engine
                gc.collect()
                torch.cuda.empty_cache()
        del model
        gc.collect()
        torch.cuda.empty_cache()
    save()


if __name__ == '__main__':
    with torch.inference_mode():
        main()
